# Slack Chess
An online multiplayer chess game with JavaScript (React and Node)

### Start the chess server

`cd server/`

`npm install` 

`npm start`

The chess server runs on `localhost:4000`

### Run the chess client

`cd client/`

`npm install`

`npm start`

The chess client runs on `localhost:3000`
