import React from 'react';
import audio from '../images/tink.wav';

export const AudioPlay = () => <audio src={audio}></audio>;

export default AudioPlay;
