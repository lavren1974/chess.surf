import React from 'react';

const Collapse = () => {
	return <div>Hello</div>;
};

export default Collapse;
