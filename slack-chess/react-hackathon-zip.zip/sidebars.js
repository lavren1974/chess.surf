module.exports = {
	someSidebar: {
		Tutorial: [
			'intro',
			'lesson1',
			'lesson2',
			'lesson2-source-code',
			'lesson3',
			'lesson4',
			'lesson5',
			'lesson6',
			'lesson7',
			'lesson8',
			'lesson9',
			'lesson10',
			'lesson11',
			'lesson12',
			'lesson13',
			'lesson14',
		],
		// Docusaurus: ['doc1', 'doc2', 'doc3'],
		// Features: ['mdx'],
	},
};
